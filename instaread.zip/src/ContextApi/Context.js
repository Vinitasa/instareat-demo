import { createContext } from "react";

const ListsContext = createContext();

export default ListsContext;
