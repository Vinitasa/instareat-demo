import { useContext, useState } from "react"
import ListsContext from "../../ContextApi/Context"
import ReactAudioPlayer from 'react-audio-player';
import './AudioPlayer.css';
import playSvg from "../../svg/play.svg";



const AudioPlayer = () => {
    const [Data, setData] = useContext(ListsContext)
    const [music, setMusic] = useState("")
    // console.log(Data.TimeStamp,'TimeStamp')
    const HandlePlay = (e, MusicName) => {
        setMusic(MusicName)

    }

    const handlePause = (e) => {
        console.log(e, "Event")
        console.log(music.Id)
        console.log(e.target.currentTime, "in handlePause")
        const clone = [...Data.TimeStamp]
        const data = { Id: music.Id, TimeStamp: e.target.currentTime }
        clone.push(data)
        setData({ ...Data, TimeStamp: clone })

    }
    const handlePlay = (e) => {
        console.log(e.target.currentTime, "in handlePlay")
        const PlayAudio = Data.TimeStamp.find(time => time.Id === music.Id)
        console.log(PlayAudio);
        e.target.currentTime = PlayAudio.TimeStamp


    }
    return (
        <>
            <ReactAudioPlayer
                src={music.file}
                autoPlay
                onPlay={(e) => handlePlay(e)}
                onPause={(e) => handlePause(e)}
                controls
            />
            <table class="table">
                <thead>

                </thead>
                <tbody>
                    {Data.Audios.map((audio, ind) => {
                        // console.log(val)
                        return (<tr key={ind}>
                            <td>{audio.Id}</td>
                            <td>{audio.fileName}</td>
                            <td onClick={(e) => HandlePlay(e, audio)}><img src={playSvg} /></td>

                        </tr>)
                    })
                    }
                </tbody>
            </table>

        </>
    )
}
export default AudioPlayer
